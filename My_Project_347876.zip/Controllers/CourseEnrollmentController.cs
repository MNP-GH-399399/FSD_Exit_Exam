﻿using FinalProject.Data;
using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CourseEnrollmentsController : ControllerBase
    {
        private readonly EnrollmentContext _context;

        public CourseEnrollmentsController(EnrollmentContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseEnrolledModel>>> GetCourseEnrollments()
        {
            return await _context.CoursesEnrolled
                .Include(ce => ce.Student) 
                .Include(ce => ce.Course)   
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CourseEnrolledModel>> GetCourseEnrollment(int id)
        {
            var enrollment = await _context.CoursesEnrolled
                .Include(ce => ce.Student)
                .Include(ce => ce.Course)
                .FirstOrDefaultAsync(ce => ce.Id == id);

            if (enrollment == null)
            {
                return NotFound();
            }

            return enrollment;
        }

        [HttpPost]
        public async Task<ActionResult<CourseEnrolledModel>> PostCourseEnrollment(CourseEnrolledModel enrollment)
        {
            _context.CoursesEnrolled.Add(enrollment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCourseEnrollment), new { id = enrollment.Id }, enrollment);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCourseEnrollment(int id, CourseEnrolledModel enrollment)
        {
            if (id != enrollment.Id)
            {
                return BadRequest();
            }

            _context.Entry(enrollment).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseEnrollmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCourseEnrollment(int id)
        {
            var enrollment = await _context.CoursesEnrolled.FindAsync(id);
            if (enrollment == null)
            {
                return NotFound();
            }

            _context.CoursesEnrolled.Remove(enrollment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CourseEnrollmentExists(int id)
        {
            return _context.CoursesEnrolled.Any(e => e.Id == id);
        }
    }
}
