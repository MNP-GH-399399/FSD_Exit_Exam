﻿using FinalProject.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.Data
{
    public class EnrollmentContext :DbContext 
    {
            public EnrollmentContext(DbContextOptions<EnrollmentContext>options):base(options) 
            {

            }
            public DbSet<StudentModel>Students { get; set; }
            public DbSet<CourseModel> Courses { get; set; }
            public DbSet<CourseEnrolledModel> CoursesEnrolled { get; set; }
    }
}
