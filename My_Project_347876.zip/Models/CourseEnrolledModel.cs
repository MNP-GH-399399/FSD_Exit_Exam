﻿namespace FinalProject.Models
{
    public class CourseEnrolledModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int courseId { get; set; }

        public StudentModel Student { get; set; } 
        public CourseModel Course { get; set; }
    }
}
