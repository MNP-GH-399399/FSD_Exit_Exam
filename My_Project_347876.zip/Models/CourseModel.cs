﻿namespace FinalProject.Models
{
    public class CourseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<CourseEnrolledModel> CourseEnrollments { get; set; }
    }
}
